export class ListJob {
    keyword: string;
    location: string;
}