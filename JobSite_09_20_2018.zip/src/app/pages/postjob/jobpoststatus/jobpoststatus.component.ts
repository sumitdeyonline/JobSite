import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jobpoststatus',
  templateUrl: './jobpoststatus.component.html',
  styleUrls: ['./jobpoststatus.component.css']
})
export class JobpoststatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
