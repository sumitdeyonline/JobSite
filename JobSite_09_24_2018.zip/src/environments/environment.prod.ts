export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDmfZp0ohd-zOuNV2hso0sfNuGpMjFtDm4",
    authDomain: "jobsite-c8333.firebaseapp.com",
    databaseURL: "https://jobsite-c8333.firebaseio.com",
    projectId: "jobsite-c8333",
    storageBucket: "jobsite-c8333.appspot.com",
    messagingSenderId: "394038370685"    
  }
};
