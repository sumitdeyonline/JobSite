import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/authentication/auth.service';
import { PostjobService } from '../../../services/firebase/postjob.service';
import { PostJobc } from '../../../services/firebase/postjob.model';

@Component({
  selector: 'jobpoststatus',
  templateUrl: './jobpoststatus.component.html',
  styleUrls: ['./jobpoststatus.component.css']
})
export class JobpoststatusComponent implements OnInit {

  pjob: PostJobc[];
  constructor(private auth: AuthService, private postservice: PostjobService) { }

  ngOnInit() {

    this.postservice.getPostJobsByUser(this.auth.userProfile.name).subscribe(pjob=> {
      this.pjob = pjob;
      //console.log("List Service ..... 33333 ::::: "+this.pjob[1].id);
    })
  }

}
