import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'midsearch',
  templateUrl: './midsearch.component.html',
  styleUrls: ['./midsearch.component.css']
})
export class MidsearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
