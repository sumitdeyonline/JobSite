export class Signup {
    username: string;
    email: string;
    password: string;
    repassword: string;
    client_id: string;
    connection: string;
    response_type: string;
}