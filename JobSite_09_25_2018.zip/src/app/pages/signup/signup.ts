export class Signup {
    username: string;
    password: string;
    repassword: string;
}